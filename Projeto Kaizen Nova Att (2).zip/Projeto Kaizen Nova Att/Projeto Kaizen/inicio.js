let currentStep = 1;
let captchaVerified = false;

function nextStep() {
    if (currentStep === 1 && validateStep1()) {
        document.getElementById('step1').style.display = 'none';
        currentStep++;
        document.getElementById('step2').style.display = 'block';
        document.querySelector('.p-2').classList.add('active');
        document.querySelector('.p-1').classList.remove('active');
    } else if (currentStep === 2 && validateStep2()) {
        document.getElementById('step2').style.display = 'none';
        currentStep++;
        if (document.getElementById('step3')) {
            document.getElementById('step3').style.display = 'block';
            document.querySelector('.p-3').classList.add('active');
            document.querySelector('.p-2').classList.remove('active');
        } 
    } else if (currentStep === 3) {
        document.getElementById('step3').style.display = 'none';
        currentStep++;
        if (document.getElementById('step4')) {
            document.getElementById('step4').style.display = 'block';
            document.querySelector('.p-4').classList.add('active');
            document.querySelector('.p-3').classList.remove('active');
            displayConfirmation();
        }
    }
}

function prevStep() {
    if (currentStep > 1) {
        if (currentStep === 2) {
            document.getElementById('step2').style.display = 'none';
            currentStep--;
            document.getElementById('step1').style.display = 'block';
        } else if (currentStep === 3) {
            document.getElementById('step3').style.display = 'none';
            currentStep--;
            document.getElementById('step2').style.display = 'block';
        } else if (currentStep === 4) {
            document.getElementById('step4').style.display = 'none';
            currentStep--;
            document.getElementById('step3').style.display = 'block';
            document.querySelector('.p-4').classList.remove('active');
            document.querySelector('.p-3').classList.add('active');
        }
    }
}

function submitForm() {
    if (captchaVerified) {
        const nome = document.getElementById('nome').value;
        const email = document.getElementById('email').value;
        const cracha = document.getElementById('cracha').value;
        const setor = document.getElementById('setor').value;
        const melhoria = document.getElementById('melhoria').value;
        const imageDataArray = [];
        const fileInput = document.getElementById('file-input');
        for (const file of fileInput.files) {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = function(event) {
                imageDataArray.push(event.target.result);
                if (imageDataArray.length === fileInput.files.length) {
                    const formDataArray = JSON.parse(localStorage.getItem('formDataArray')) || [];
                    const formData = {
                        nome: nome,
                        email: email,
                        cracha: cracha,
                        setor: setor,
                        melhoria: melhoria,
                        images: imageDataArray
                    };
                    formDataArray.push(formData);
                    localStorage.setItem('formDataArray', JSON.stringify(formDataArray));

                    displayConfirmationMessage();
                }
            }
        }
    }
}

function displayConfirmationMessage() {
    const confirmationMessage = document.getElementById('confirmationMessage');
    confirmationMessage.innerText = 'O formulário foi enviado com sucesso!';
    confirmationMessage.style.display = 'block';
}

function displayFormData() {
    const formDataArray = JSON.parse(localStorage.getItem('formData'));
    if (formDataArray) {
        const nome = localStorage.getItem('nome');
        const email = localStorage.getItem('email');
        const cracha = localStorage.getItem('cracha');
        const setor = localStorage.getItem('setor');
        const melhoria = localStorage.getItem('melhoria');

        const fileListItems = Array.from(document.querySelectorAll('#file-list li span'));
        const fileList = fileListItems.map(item => item.textContent);

        let fileListHTML = '';
        if (fileList.length > 0) {
            fileListHTML += '<p><strong>Arquivos enviados:</strong></p><ul>';
            fileList.forEach(fileName => {
                fileListHTML += `<li>${fileName}</li>`;
            });
            fileListHTML += '</ul>';
        }

        const confirmationHTML = ` 
            <p><strong>Nome:</strong> ${nome}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Crachá:</strong> ${cracha}</p>
            <p><strong>Setor:</strong> ${setor}</p>
            <p><strong>Melhoria:</strong> ${melhoria}</p>
            ${fileListHTML}
        `;

        document.getElementById('confirmation').innerHTML = confirmationHTML;
    } else {
        document.getElementById('confirmation').innerHTML = "<p>Nenhum dado encontrado.</p>";
    }
}

function showCaptcha() {
    captchaWord = generateCaptcha();
    document.getElementById('captchaWord').innerText = captchaWord;
    document.getElementById('captchaModal').style.display = 'block';
    document.getElementById('submitBtn').disabled = true; 
}

function closeModal() {
    document.getElementById('captchaModal').style.display = 'none';
}

function generateCaptcha() {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let captcha = '';
    for (let i = 0; i < 8; i++) {
        captcha += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    }
    return captcha;
}

function checkCaptcha() {
    const inputCaptcha = document.getElementById('captchaInput').value;
    if (inputCaptcha === captchaWord) {
        document.getElementById('captchaModal').style.display = 'none';
        captchaVerified = true;
        console.log("true");
        document.getElementById('submitBtn').disabled = false;
        submitForm();
    } else {
        alert('Captcha incorreto. Tente novamente.');
    }
}

function validateStep1() {
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const cracha = document.getElementById('cracha').value;
    return nome && email && cracha;
}

function validateStep2() {
    const setor = document.getElementById('setor').value;
    const melhoria = document.getElementById('melhoria').value;
    return setor && melhoria;
}

const dropArea = document.getElementById('drop-area');
const fileList = document.getElementById('file-list');
const fileInput = document.getElementById('file-input');
const fileSelect = document.getElementById('file-select');

dropArea.addEventListener('dragover', (event) => {
    event.preventDefault();
    dropArea.classList.add('highlight');
});

dropArea.addEventListener('dragleave', () => {
    dropArea.classList.remove('highlight');
});

dropArea.addEventListener('drop', (event) => {
    event.preventDefault();
    dropArea.classList.remove('highlight');
    const files = event.dataTransfer.files;
        handleFiles(files);
});

fileSelect.addEventListener('click', (event) => {
    event.preventDefault();
    fileInput.click();
});

fileInput.addEventListener('change', (event) => {
    const files = event.target.files;
    handleFiles(files);
});

function getFileType(fileName) {
    const extension = fileName.split('.').pop().toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif'].includes(extension)) {
        return 'image';
    } else if (['doc', 'docx', 'pdf', 'txt'].includes(extension)) {
        return 'document';
    } else if (['mp4', 'avi', 'mkv', 'mov'].includes(extension)) {
        return 'video';
    } else {
        return 'other';
    }
}

function handleFiles(files) {
    for (const file of files) {
        const listItem = document.createElement('li');
        const fileType = getFileType(file.name);
        const fileItem = document.createElement('div');
        fileItem.classList.add('file-item');
        const fileIcon = document.createElement('img');
        fileIcon.classList.add('file-icon');
        fileIcon.src = getFileIconPath(fileType);
        const fileDetails = document.createElement('div');
        fileDetails.classList.add('file-details');
        const fileNameElement = document.createElement('span');
        fileNameElement.textContent = file.name;
        const removeButton = document.createElement('button');
        removeButton.classList.add('button');
        removeButton.textContent = 'Excluir';
        removeButton.addEventListener('click', () => {
            listItem.remove();
        });
        fileDetails.appendChild(fileNameElement);
        fileDetails.appendChild(removeButton);
        fileItem.appendChild(fileIcon);
        fileItem.appendChild(fileDetails);
        listItem.appendChild(fileItem);
        const progressBar = document.createElement('div');
        progressBar.classList.add('progress-bar');
        const progressBarInner = document.createElement('div');
        progressBarInner.classList.add('progress-bar-inner');
        progressBar.appendChild(progressBarInner);
        listItem.appendChild(progressBar);
        fileList.appendChild(listItem);
        uploadFile(file, progressBarInner);
    }
}

function uploadFile(file, progressBarInner) {
    let progress = 0;
    const progressInterval = setInterval(() => {
        if (progress < 50) {
            progressBarInner.style.width = progress + '%';
            progressBarInner.style.backgroundColor = '#f00'; 
        } else if (progress < 100) {
            progressBarInner.style.width = progress + '%';
            progressBarInner.style.backgroundColor = '#ff0'; 
        } else {
            progressBarInner.style.width = '100%';
            progressBarInner.style.backgroundColor = '#0f0'; 
            clearInterval(progressInterval);
        }
        progress += 10;
    }, 200);
    setTimeout(() => {
        clearInterval(progressInterval);
        progressBarInner.style.backgroundColor = '#0f0'; 
    }, 3000); 
}

function getFileIconPath(fileType) {
    switch (fileType) {
        case 'image':
            return 'imagem.png'; 
        case 'document':
            return 'documento.png'; 
        case 'video':
            return 'video.png'; 
            default:
            return 'generico.png'; 
        }
}

function displayConfirmation() {


    const formData = JSON.parse(localStorage.getItem('formData'));
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const cracha = document.getElementById('cracha').value;
    const setor = document.getElementById('setor').value;
    const melhoria = document.getElementById('melhoria').value;
    const fileListItems = Array.from(document.querySelectorAll('#file-list li span'));
    const fileList = fileListItems.map(item => item.textContent);
    let fileListHTML = '';
    if (fileList.length > 0) {
        fileListHTML += '<p><strong>Arquivos enviados:</strong></p><ul>';
        fileList.forEach(fileName => {
            fileListHTML += `<li>${fileName}</li>`;
        });
        fileListHTML += '</ul>';
    }

    const confirmationHTML = ` 
            
            <p><strong>Nome:</strong> ${nome}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Crachá:</strong> ${cracha}</p>
            <p><strong>Setor:</strong> ${setor}</p>
            <p><strong>Melhoria:</strong> ${melhoria}</p>


        `;

    document.getElementById('confirmation').innerHTML = confirmationHTML;

} 

    















