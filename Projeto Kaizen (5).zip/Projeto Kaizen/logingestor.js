function showRegistration() {
    document.querySelector('.sign-in').style.display = 'none';
    document.querySelector('.sign-up').style.display = 'block';
}

function register() {
    const newUsername = document.getElementById('newUsername').value;
    const newPassword = document.getElementById('newPassword').value;

    // Verifica se o usuário já existe
    if (localStorage.getItem(newUsername) !== null) {
        alert('Esse usuário já existe.');
        return; // Parar a execução da função se o usuário já existir
    }

    // Registra o novo usuário
    localStorage.setItem(newUsername, JSON.stringify({ password: newPassword }));
    alert('Registro realizado com sucesso! Você pode fazer login agora.');
    showLogin(); // Após registrar, mostra a tela de login
}

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const storedUser = localStorage.getItem(username);

    if (storedUser && JSON.parse(storedUser).password === password) {
        // Marcar o usuário como logado
        localStorage.setItem('loggedInUser', username);
        // Redirecionar para a página correta
        window.location.href = "recebimento.html"
    } else {
        alert('Usuário ou senha incorretos!');
    }
}

function showLogin() {
    document.querySelector('.sign-in').style.display = 'block';
    document.querySelector('.sign-up').style.display = 'none';
}

function enableLoginBtn() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    document.getElementById('loginBtn').disabled = !(username && password);
}

document.getElementById('username').addEventListener('input', enableLoginBtn);
document.getElementById('password').addEventListener('input', enableLoginBtn);

// Inicializar a verificação de autenticação
showLogin();