document.addEventListener('DOMContentLoaded', function () {
    const feedbackDataElement = document.getElementById('feedback-data');
    const formDataArray = JSON.parse(localStorage.getItem('formDataArray')) || [];
    let html = `
        <table border="1">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Crachá</th>
                    <th>Setor</th>
                    <th>Melhoria</th>
                    <th>Anexos</th>
                    <th>Selecionar</th>
                </tr>
            </thead>
            <tbody>
    `;

    formDataArray.forEach((formData, index) => {
        let imagesHTML = '';
        if (formData.images && formData.images.length > 0) {
            imagesHTML += '<ul class="ul-img">';
            formData.images.forEach(imageData => {
                imagesHTML += `<li class="li-img"><img src="${imageData}" class="uploaded-image"></li>`;
            });
            imagesHTML += '</ul>';
        }
        html += `
            <tr>
                <td>${index + 1}</td>
                <td>${formData.nome}</td>
                <td>${formData.email}</td>
                <td>${formData.cracha}</td>
                <td>${formData.setor}</td>
                <td>${formData.melhoria}</td>
                <td>${imagesHTML}</td>
                <td><input type="checkbox" class="checkbox" data-index="${index}"></td>
            </tr>
        `;
    });

    html += `
            </tbody>
        </table>
        <button id="delete-selected" style="display:none;"><img src="excluir.png" class="delete-icon"></button>
    `;

    feedbackDataElement.innerHTML = html;

    const fileListItems = document.querySelectorAll('.file-list-item');
    fileListItems.forEach(item => {
        item.addEventListener('click', function (event) {
            const fileName = this.textContent;
            const fileURL = this.getAttribute('data-url');
            if (fileName.match(/\.(jpg|jpeg|png|gif)$/i)) {
                const modal = document.getElementById('myModal');
                const modalImg = document.getElementById('img01');
                modal.style.display = 'block';
                modalImg.src = fileURL;
                const span = document.getElementsByClassName('close')[0];
                span.onclick = function() {
                    modal.style.display = 'none';
                };
            } else {
                window.open(fileURL, '_blank');
            }
        });
    });

    const checkboxes = document.querySelectorAll('.checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function () {
            const deleteSelectedBtn = document.getElementById('delete-selected');
            const anyChecked = Array.from(checkboxes).some(cb => cb.checked);

            if (anyChecked) {
                deleteSelectedBtn.style.display = 'inline-block';
            } else {
                deleteSelectedBtn.style.display = 'none';
            }
        });
    });

    const deleteSelectedBtn = document.getElementById('delete-selected');
    deleteSelectedBtn.addEventListener('click', function () {
        const checkboxes = document.querySelectorAll('.checkbox:checked');
        const selectedIndexes = Array.from(checkboxes).map(cb => parseInt(cb.getAttribute('data-index')));
        selectedIndexes.sort((a, b) => b - a).forEach(index => {
            formDataArray.splice(index, 1);
        });

        localStorage.setItem('formDataArray', JSON.stringify(formDataArray));
        renderTable(formDataArray);
        this.style.display = 'none';
    });

    function renderTable(formDataArray) {
        let tableBody = '';
        formDataArray.forEach((formData, index) => {
            tableBody += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${formData.nome}</td>
                    <td>${formData.email}</td>
                    <td>${formData.cracha}</td>
                    <td>${formData.setor}</td>
                    <td>${formData.melhoria}</td>
                    <td><input type="checkbox" class="checkbox" data-index="${index}"></td>
                </tr>
            `;
        });
        feedbackDataElement.querySelector('tbody').innerHTML = tableBody;
    }
});
